import CoreBrandLogo from "@core/components/CoreBranding/CoreBrandLogo";
import CoreBrandName from "@core/components/CoreBranding/CoreBrandName";
import { Box } from "@mui/material";

type LogoWithNameProps = {
  projectName: string;
};

const LogoWithName: React.FC<LogoWithNameProps> = ({ projectName }) => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        textAlign: "center",
        mb: 4,
      }}
    >
      <CoreBrandLogo width={60} height={60} />
      <CoreBrandName>{projectName}</CoreBrandName>
    </Box>
  );
};

export default LogoWithName;
